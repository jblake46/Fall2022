#include <stdio.h>
#include "functions.h"
//added change bc the makefile was bieng weird
int main(int argc, char* argv[])
{
    printf("%d\n",sum(5, 10));
    return 0;
}