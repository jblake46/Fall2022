i had some trouble just understanding what to do, the instructions were kind of cluttered, so i found myself asking a lot of
people questions. i dont know if its because im dumb or what, but it was hard to understand what was being asked and how to execute it.

another problem i had was not being sure if i had to worry about comments, so i made a function to do so, like how we had in lab
once again, the instructions weren't the clearest, i asked around, so people were worrying about them some werent, so i worried about
it and created a function for it

i thought it was a cool assignment, i like being secretive and i thought it was a really cool step into encryption. so i liked that aspect of it
however, i did not enjoy the lack of clarity in the instructions. yes i could ask questions and i did, but i felt like a burden bugging people
with my questions.