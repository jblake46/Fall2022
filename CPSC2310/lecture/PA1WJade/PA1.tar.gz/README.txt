I ran into a segfault for the resize function
    but that was because i was using the width for the row so i just had to 
    stare at the code for awhile until i realized

I also confused myself with the negative ppm because i thought it was the rgb values - 255
but it was actually the other way around

To be honest i really didn't love or hate the assignment
    i just really hate ppm images but i finally understand them better now 

Communication between two people and their different coding styles were also a bump in the road
    but i guess thats what good coding practice is for
    